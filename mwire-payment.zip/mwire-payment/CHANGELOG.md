## 0.0.2 [2020-04-12]

- Fixed Updater Script


## 0.0.1 [2020-04-12]

- Updated order status to initially be "on hold"
